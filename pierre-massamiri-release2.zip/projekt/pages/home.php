

<section>
    <div id="mastsealborder">
      <div id="mastseal">
         <img id="sealfront" alt="seal_front" src="img/1557732_10151882513731325_2105109648_n.jpg">
         <img id="sealback" alt="seal_back" src="img/keep-calm.png">
     </div>
   </div> 
    <div class="left-count">
      <h2 class="count-header">Dagar till examen:</h2>
        <div id="timer">
          <div id="daysExam"></div>
          <div id="hoursExam"></div>
        </div>
      </div>
    <div class="right-count">
      <h2 class="count-header">LIAn startar om:</h2>
        <div id="timer">
          <div id="daysLia"></div>
          <div id="hoursLia"></div>
        </div>
      </div>
<ul class="share-buttons">
  <li><a href="https://www.facebook.com/sharer/sharer.php?u=http%3A%2F%2Fwww.pierremassamiri.se&t=Pierre%20Massamiri" title="Share on Facebook" target="_blank"><img alt="Share on Facebook" src="img/Facebook.png"></a></li>
  <li><a href="https://twitter.com/intent/tweet?source=http%3A%2F%2Fwww.pierremassamiri.se&text=Pierre%20Massamiri:%20http%3A%2F%2Fwww.pierremassamiri.se" target="_blank" title="Tweet"><img alt="Tweet" src="img/Twitter.png"></a></li>
  <li><a href="https://plus.google.com/share?url=http%3A%2F%2Fwww.pierremassamiri.se" target="_blank" title="Share on Google+"><img alt="Share on Google+" src="img/Google+.png"></a></li>
</ul>
</section>

<?php include('footer.php'); ?>

  <script src="js/game.js"></script>
  <script src="js/responsive-menu.js"></script>
  <script src="js/countdown.js"></script> 
</body> 
</html>