<?php include("db_connect.php");?>

<section class="second">
 <h2>Kontakta mig</h2>
   <div id="frame">
     <div id="mail">
        <img src="img/kontakt.png" alt="email"><p class="contact-text"> <a href="http://localhost/pierremassamamiri.se/projekt/pages/index.php" target="popup" 
        onclick="window.open('http://localhost/pierremassamamiri.se/projekt/pages/index.php','popup','width=580,height=468,scrollbars=no,resizable=no'); return false;">
        Kontakta mig</p>
       
      </a>
    </div>
 <div id="phone">
    <img src="img/phone.png" alt="telefon kontakt"> <p class="contact-text">Mobil: 070-769 33 42</p>
    </div>
    <div id="location">
    <img src="img/location.png" alt="location"> <p class="contact-text">Bodalsvägen 22<br />181 37 Lidingö</p>
    </div>
    </div>
</section>
<ul class="share-buttons">
  <li><a href="https://www.facebook.com/sharer/sharer.php?u=http%3A%2F%2Fwww.pierremassamiri.se&t=Pierre%20Massamiri" title="Share on Facebook" target="_blank"><img alt="Share on Facebook" src="img/Facebook.png"></a></li>
  <li><a href="https://twitter.com/intent/tweet?source=http%3A%2F%2Fwww.pierremassamiri.se&text=Pierre%20Massamiri:%20http%3A%2F%2Fwww.pierremassamiri.se" target="_blank" title="Tweet"><img alt="Tweet" src="img/Twitter.png"></a></li>
  <li><a href="https://plus.google.com/share?url=http%3A%2F%2Fwww.pierremassamiri.se" target="_blank" title="Share on Google+"><img alt="Share on Google+" src="img/Google+.png"></a></li>
</ul>
<?php include('footer.php');?>
  <script src="js/game.js"></script>
  <script src="js/responsive-menu.js"></script>
</body> 
</html>