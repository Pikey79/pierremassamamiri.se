<section class="second">
	<h2>Portfolio</h2>
	<div id="porfolio-frame">
     
      <ul class="rig columns-3">
    	<li>
    		<img src="img/alltomkosttillskott.png" />
    		<h3>Alltomkosttillskott.se</h3>
    		<p>Jämför priser på kosttillskott online</p>
    	</li>
    	<li>
    		<img src="img/furnituremall.png" />
    		<h3>Furnituremall.se</h3>
    		<p>En galleria för möbler och inredning</p>
    	</li>
    	<li>
    		<img src="img/hittasmin.png" />
    		<h3>Hittasmink.se</h3>
    		<p>Jämför sminkpriser online</p>
    	</li>
    	
    </ul>
</div>
<br>
<br>
<iframe width="560" height="315" src="https://www.youtube.com/embed/Td-2D-_7Y2E" frameborder="0" allowfullscreen></iframe>
<br>
<br>
<br>

</section>
<ul class="share-buttons">
  <li><a href="https://www.facebook.com/sharer/sharer.php?u=http%3A%2F%2Fwww.pierremassamiri.se&t=Pierre%20Massamiri" title="Share on Facebook" target="_blank"><img alt="Share on Facebook" src="img/Facebook.png"></a></li>
  <li><a href="https://twitter.com/intent/tweet?source=http%3A%2F%2Fwww.pierremassamiri.se&text=Pierre%20Massamiri:%20http%3A%2F%2Fwww.pierremassamiri.se" target="_blank" title="Tweet"><img alt="Tweet" src="img/Twitter.png"></a></li>
  <li><a href="https://plus.google.com/share?url=http%3A%2F%2Fwww.pierremassamiri.se" target="_blank" title="Share on Google+"><img alt="Share on Google+" src="img/Google+.png"></a></li>
</ul>
<?php include('footer.php');?>
  <script src="js/game.js"></script>
  <script src="js/responsive-menu.js"></script>
</body> 
</html>