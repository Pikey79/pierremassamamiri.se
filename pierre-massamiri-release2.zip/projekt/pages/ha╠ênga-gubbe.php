
<section class="second">
   <h2>Hänga gubbe</h2>
   <div id="frame">
    <div id="hangman">
<button id="btnGame" type="submit">Spela</button>
<p id="progressDisplay"></p>
</div>
</div>
<ul class="share-buttons">
  <li><a href="https://www.facebook.com/sharer/sharer.php?u=http%3A%2F%2Fwww.pierremassamiri.se&t=Pierre%20Massamiri" title="Share on Facebook" target="_blank"><img alt="Share on Facebook" src="img/Facebook.png"></a></li>
  <li><a href="https://twitter.com/intent/tweet?source=http%3A%2F%2Fwww.pierremassamiri.se&text=Pierre%20Massamiri:%20http%3A%2F%2Fwww.pierremassamiri.se" target="_blank" title="Tweet"><img alt="Tweet" src="img/Twitter.png"></a></li>
  <li><a href="https://plus.google.com/share?url=http%3A%2F%2Fwww.pierremassamiri.se" target="_blank" title="Share on Google+"><img alt="Share on Google+" src="img/Google+.png"></a></li>
</ul>
</section>

<?php include('footer.php'); ?>
  
  <script src="js/hangman.js"></script>
  <script src="js/responsive-menu.js"></script>
</body> 
</html>