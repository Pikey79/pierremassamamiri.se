<footer>
    <p>

    	<a class="login-link" href="http://localhost/pierremassamamiri.se/projekt/pages/loginpage.php">Logga in</a><br><br>

©2016 <a href="home.php">Pierre Massamiri</a>
</p>
</footer>