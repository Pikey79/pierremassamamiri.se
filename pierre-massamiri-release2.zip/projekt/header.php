<!DOCTYPE html>
<html>
<head>
  <title>Pierre Massamiri</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" type="text/css" href="css/style.css">
  <link href="https://fonts.googleapis.com/css?family=Raleway" rel="stylesheet">
  <script src="http://ajax.aspnetcdn.com/ajax/jQuery/jquery-1.5.min.js" type="text/javascript"></script>
  <script src="http://ajax.googleapis.com/ajax/libs/jqueryui/1.8.9/jquery-ui.min.js" type="text/javascript"></script>
</head>
<body>
  <header>
    <a href="index.php?page=home"><h1>\PM/</h1></a>
    <nav>
      <ul class="topnav" id="myTopnav">
        <li><a href="index.php?page=cv">Mitt cv</a></li>
        <li><a href="index.php?page=kontakt">Kontakt</a></li>
        <li><a href="index.php?page=portfolio">Portfolio</a></li>
        
        <li class="icon">
        <a href="javascript:void(0);" onclick="myFunction()">&#9776;</a>
        </li>
      </ul>
    </nav>
   </header>

   

